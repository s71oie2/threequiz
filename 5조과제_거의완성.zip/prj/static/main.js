/* prj/static/main.js */
console.log("prj/static/main.js 파일을 로드했습니다.");